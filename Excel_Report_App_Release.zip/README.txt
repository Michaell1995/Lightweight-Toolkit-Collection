Excel Report Generator
======================

This is a standalone Windows desktop app that lets you:
- Drag and drop multiple Excel or CSV files
- Automatically generate a combined report
- Includes file counts, branch totals/averages, and missing data checks

How to Use
----------
1. Open `excel_report_app.exe`
2. Drag Excel or CSV files into the app window
3. Click "Generate Report"
4. The summary report will be saved in an 'output' folder

What's Included
---------------
- `excel_report_app.exe`: The app (no Python required)
- `README.txt`: This file
- `sample_files/`: A few example files you can test with

Support
-------
For support or feature requests, contact mlanzalotti1995@gmail.com
